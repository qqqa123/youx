// 获取用户信息


module.exports={

    getuserBYusermaneL:(username)=>{

    },
    // 用户注册
    adduser :(user)=>{

    },
    // 更新数据
    update:(arr)=>{

    },
    // 删除数据
deleteuser:(id)=>{

    this.update([{id_del:1},id])
},
// 获取用户的所有信息
getuser:() =>{

}

}