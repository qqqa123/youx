const { log } = require('console')
const express = require('express')
const app = express()
const fs =require('fs')
const {mysqldb} =require('./sql/js/mysqldb.js')
const port = 2500



app.use(express.static(__dirname + '/wed'))//设置wed为静态目录

// 这个路由负责登录
app.get('/thelogin', (req, res) => {
  res.send('我是负责登录的')
  


})


// 这个路由负责注册
app.get('/registered', (req, res) => {
  

})



// 这个路由负责找回密码
app.get('/zp', (req, res) => {
  

})


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

