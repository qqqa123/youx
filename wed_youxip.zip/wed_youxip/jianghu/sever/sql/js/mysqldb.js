const mysql=require('mysql')
// 配置数据库连接信息
const config ={
   
    database :'user',//数据库名称
    user:'root',//数据库用户名
 password:''//密码
}
exports.musqldb=(sqllike,sqlparams)=>{
//sqlparams为空的处理方法
  sqlparams=sqlparams||[]
       return new Promise((resolve,reject) => {


        const pool=mysql.createPool(config)
  pool.getConnection((err,sql) =>{
        if (!err) {
         
        sql.query(sqllike,sqlparams,(e,results) =>{
          if (!e) {
          
          //res.send()
        resolve(results);

          sql.destroy()
        }
    
        else{
            console.log(e);
            reject(err)
          }
        
      })
        } else{
          console.log(e);
        }
       
  })
       })
}

